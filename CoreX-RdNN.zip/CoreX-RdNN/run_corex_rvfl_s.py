import os
import numpy as np
import scipy.io
from sklearn.preprocessing import StandardScaler
from models.corex_s_func import RVFL_Model

# File to save results
result_file = r"./results/corex_rvfl_s.txt"
with open(result_file, 'w') as result:
    result.write("DataSetName\tBestMeanTrainAccuracy\tBestStdTrainAccuracy\tBestMeanTestAccuracy\t"
                 "BestStdTestAccuracy\tBestMeanTrainTime\tBestStdTrainTime\t"
                 "BestMeanTestTime\tBestStdTestTime\tBest_C\tBest_e\tBest_Activation\tBest_Gamma\n")

# Directory of datasets
directory = r"./datasets"
files = [f for f in os.listdir(directory) if f.endswith('.mat')]

for file in files:
    # Load dataset
    data_path = os.path.join(directory, file)
    file_data = scipy.io.loadmat(data_path)

    # Identify the dataset key (skip keys starting with '__')
    dataset_key = next((key for key in file_data.keys() if not key.startswith('__')), None)

    if dataset_key is None:
        print(f"No valid dataset key found in {file}.")
        continue  # Skip this file if no valid key is found

    # Access the dataset using the identified key
    all_data = file_data[dataset_key]

    # Preprocessing
    X = StandardScaler().fit_transform(all_data[:, :-1])
    y = all_data[:, -1]
    num_classes = len(np.unique(y))
    y = y.astype(int)  # Ensure class labels are integers

    # Combine features and labels
    all_data = np.hstack((X, y.reshape(-1, 1)))

    length_train = all_data.shape[0]

    # Hyperparameters
    C = 0.00001
    e = 103
    activation = 6
    gamma_ = 0

    best_metrics = {
        'MeanTrainAccuracy': 0,
        'MeanTestAccuracy': 0,
    }

    temp_results = []
    temp_test_accuracy = []

    block_size = length_train // 5

    for part in range(5):
        t1 = part * block_size
        t2 = (part + 1) * block_size

        test_data = all_data[t1:t2, :]
        train_data = np.vstack((all_data[:t1, :], all_data[t2:, :]))

        trainX, trainY = train_data[:, :-1], train_data[:, -1]
        testX, testY = test_data[:, :-1], test_data[:, -1]

        option = {'C': C, 'N': e, 'activation': activation}

        train_acc, valid_acc, train_time, valid_time = RVFL_Model(
            trainX, trainY, testX, testY, option, num_classes, gamma_
        )

        temp_results.append([train_acc, valid_acc, train_time, valid_time])
        temp_test_accuracy.append(valid_acc)

    mean_test_accuracy = np.mean(temp_test_accuracy)
    if mean_test_accuracy > best_metrics['MeanTestAccuracy']:
        best_metrics.update({
            'MeanTrainAccuracy': np.mean(np.array(temp_results)[:, 0]),
            'StdTrainAccuracy': np.std(np.array(temp_results)[:, 0]),
            'MeanTestAccuracy': mean_test_accuracy,
            'StdTestAccuracy': np.std(np.array(temp_results)[:, 1]),
            'MeanTrainTime': np.mean(np.array(temp_results)[:, 2]),
            'StdTrainTime': np.std(np.array(temp_results)[:, 2]),
            'MeanTestTime': np.mean(np.array(temp_results)[:, 3]),
            'StdTestTime': np.std(np.array(temp_results)[:, 3]),
            'C': C,
            'N': e,
            'Activation': activation,
            'Best_gamma': gamma_
        })

    # Log results
    print(f"Done processing {file}")
    # print("Done")
    with open(result_file, 'a') as result:
        result.write(f"{file}\t{best_metrics['MeanTrainAccuracy']:.4f}\t{best_metrics['StdTrainAccuracy']:.4f}\t"
                     f"{best_metrics['MeanTestAccuracy']:.4f}\t{best_metrics['StdTestAccuracy']:.4f}\t"
                     f"{best_metrics['MeanTrainTime']:.4f}\t{best_metrics['StdTrainTime']:.4f}\t"
                     f"{best_metrics['MeanTestTime']:.4f}\t{best_metrics['StdTestTime']:.4f}\t"
                     f"{best_metrics['C']:.6f}\t{best_metrics['N']}\t{best_metrics['Activation']}\t{best_metrics['Best_gamma']}\n")
