import numpy as np
import time

def fix_zero_variance_columns(features, epsilon=1e-10):
    std_dev = np.std(features, axis=0)
    std_dev[std_dev < epsilon] = epsilon  # Force minimum variance
    adjusted_features = features / std_dev
    return adjusted_features

def compute_laplacian(features, threshold=0.5):

    # Compute correlation matrix
    similarity_matrix = np.corrcoef(features.T)
    similarity_matrix = np.nan_to_num(similarity_matrix)  # Replace NaNs with 0

    # Threshold similarity matrix
    adjacency_matrix = (np.abs(similarity_matrix) > threshold).astype(float)

    # Compute degree and Laplacian matrices
    degree_matrix = np.diag(np.sum(adjacency_matrix, axis=1))
    laplacian_matrix = degree_matrix - adjacency_matrix

    return laplacian_matrix, adjacency_matrix



def RVFL_Model(trainX, trainY, testX, testY, option, No_of_class, lambda_reg):
    N = option['N']
    C = option['C']
    s = 1  # Scaling factor
    activation = option['activation']

    # Convert labels to one-hot encoding
    def one_hot_encode(labels, num_classes):
        one_hot = np.zeros((len(labels), num_classes))
        one_hot[np.arange(len(labels)), labels.astype(int)] = 1
        return one_hot

    trainY_one_hot = one_hot_encode(trainY, No_of_class)

    # Start training
    start_time = time.time()

    Nsample, Nfea = trainX.shape
    W = np.random.uniform(-s, s, (Nfea, N))
    b = np.random.uniform(0, s, N)

    X1 = np.dot(trainX, W) + b




    # Activation functions
    if activation == 1:
        X1 = 1 / (1 + np.exp(-X1))  # Sigmoid
    elif activation == 2:
        X1 = np.sin(X1)  # Sine
    elif activation == 3:
        X1 = np.maximum(0, 1 - np.abs(X1))  # Tribas
    elif activation == 4:
        X1 = np.exp(-X1**2)  # Radbas
    elif activation == 5:
        X1 = np.tanh(X1)  # Tansig
    elif activation == 6:
        X1 = np.maximum(0, X1)

    Z = np.concatenate((trainX, X1), axis=1)
    L,A= compute_laplacian(Z)

    Z_T_Z = Z.T @ Z               # Z^T Z, shape: (d + m, d + m)
    Z_T_Y = Z.T @ trainY_one_hot              # Z^T Y, shape: (d + m, c)
    I = np.eye(Z_T_Z.shape[0])    # Identity matrix, shape: (d + m, d + m)
    
    beta = np.linalg.inv(Z_T_Z + lambda_reg * L + (1 / C) * I) @ Z_T_Y




    trainY_pred = np.dot(Z, beta)
    train_time = time.time() - start_time

    # Softmax and accuracy calculation
    train_probs = np.exp(trainY_pred - np.max(trainY_pred, axis=1, keepdims=True))
    train_probs /= np.sum(train_probs, axis=1, keepdims=True)
    train_preds = np.argmax(train_probs, axis=1)
    train_acc = np.mean(train_preds == np.argmax(trainY_one_hot, axis=1)) * 100

    # Start testing
    start_time = time.time()

    testY_one_hot = one_hot_encode(testY, No_of_class)

    Nsample = testX.shape[0]
    X1 = np.dot(testX, W) + b

    # Activation functions
    if activation == 1:
        X1 = 1 / (1 + np.exp(-X1))  # Sigmoid
    elif activation == 2:
        X1 = np.sin(X1)  # Sine
    elif activation == 3:
        X1 = np.maximum(0, 1 - np.abs(X1))  # Tribas
    elif activation == 4:
        X1 = np.exp(-X1**2)  # Radbas
    elif activation == 5:
        X1 = np.tanh(X1)  # Tansig
    elif activation == 6:
        X1 = np.maximum(0, X1)

    X = np.hstack((testX, X1))

    testY_pred = np.dot(X, beta)
    test_time = time.time() - start_time

    test_probs = np.exp(testY_pred - np.max(testY_pred, axis=1, keepdims=True))
    test_probs /= np.sum(test_probs, axis=1, keepdims=True)
    test_preds = np.argmax(test_probs, axis=1)
    test_acc = np.mean(test_preds == np.argmax(testY_one_hot, axis=1)) * 100

    return train_acc, test_acc, train_time, test_time, A
