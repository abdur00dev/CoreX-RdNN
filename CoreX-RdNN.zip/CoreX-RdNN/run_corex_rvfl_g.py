import os
import numpy as np
import scipy.io
import pandas as pd
from sklearn.preprocessing import StandardScaler
from models.corex_g_func import RVFL_Model
import warnings
 # File to save results
result_file = r"./results/corex_rvfl_g.txt"
with open(result_file, 'w') as result:
    result.write("DataSetName\tBestMeanTrainAccuracy\tBestStdTrainAccuracy\tBestMeanTestAccuracy\t"
                  "BestStdTestAccuracy\tBestMeanTrainTime\tBestStdTrainTime\t"
                  "BestMeanTestTime\tBestStdTestTime\tBest_C\tBest_e\tBest_Activation\tBest_Lambda\n")


directory = r"./datasets"
files = [f for f in os.listdir(directory) if f.endswith('.mat')]

for file in files:
    # Load dataset
    data_path = os.path.join(directory, file)
    file_data = scipy.io.loadmat(data_path)
    
    # Identify the dataset key (skip keys starting with '__')
    dataset_key = next((key for key in file_data.keys() if not key.startswith('__')), None)
    
    if dataset_key is None:
        print(f"No valid dataset key found in {file}.")
        continue  # Skip this file if no valid key is found

    # Access the dataset using the identified key
    all_data = file_data[dataset_key]

    # Preprocessing
    all_data[all_data[:, -1] == -1, -1] = 0
    X = StandardScaler().fit_transform(all_data[:, :-1])
    y = all_data[:, -1].astype(int)
    all_data = np.hstack((X, y.reshape(-1, 1)))

    num_classes = len(np.unique(y))
    length_train = all_data.shape[0]


    # Hyperparameters
    C = 0.00001
    e = 103
    activation = 6
    lambda_ = 0.01




    best_metrics = {
        'MeanTrainAccuracy': 0,
        'MeanTestAccuracy': 0,
    }

    temp_results = []
    temp_test_accuracy = []

    block_size = length_train // 5

    for part in range(5):
        t1 = part * block_size
        t2 = (part + 1) * block_size

        test_data = all_data[t1:t2, :]
        train_data = np.vstack((all_data[:t1, :], all_data[t2:, :]))

        trainX, trainY = train_data[:, :-1], train_data[:, -1]
        testX, testY = test_data[:, :-1], test_data[:, -1]

        option = {'C': C, 'N': e, 'activation': activation}

        train_acc, valid_acc, train_time, valid_time, _ = RVFL_Model(
            trainX, trainY, testX, testY, option, num_classes, lambda_
        )

        temp_results.append([train_acc, valid_acc, train_time, valid_time])
        temp_test_accuracy.append(valid_acc)

    mean_test_accuracy = np.mean(temp_test_accuracy)
    if mean_test_accuracy > best_metrics['MeanTestAccuracy']:
        best_metrics.update({
            'MeanTrainAccuracy': np.mean(np.array(temp_results)[:, 0]),
            'StdTrainAccuracy': np.std(np.array(temp_results)[:, 0]),
            'MeanTestAccuracy': mean_test_accuracy,
            'StdTestAccuracy': np.std(np.array(temp_results)[:, 1]),
            'MeanTrainTime': np.mean(np.array(temp_results)[:, 2]),
            'StdTrainTime': np.std(np.array(temp_results)[:, 2]),
            'MeanTestTime': np.mean(np.array(temp_results)[:, 3]),
            'StdTestTime': np.std(np.array(temp_results)[:, 3]),
            'C': C,
            'N': e,
            'Activation': activation,
            'Best_lamb': lambda_
        })

    # Log results
    print(f"Done processing {file}")
    with open(result_file, 'a') as result:
        result.write(f"{file}\t{best_metrics.get('MeanTrainAccuracy', 0):.4f}\t{best_metrics.get('StdTrainAccuracy', 0):.4f}\t"
                     f"{best_metrics.get('MeanTestAccuracy', 0):.4f}\t{best_metrics.get('StdTestAccuracy', 0):.4f}\t"
                     f"{best_metrics.get('MeanTrainTime', 0):.4f}\t{best_metrics.get('StdTrainTime', 0):.4f}\t"
                     f"{best_metrics.get('MeanTestTime', 0):.4f}\t{best_metrics.get('StdTestTime', 0):.4f}\t"
                     f"{best_metrics.get('C', 0.0):.6f}\t{best_metrics.get('N', 0)}\t{best_metrics.get('Activation', 0)}\t"
                     f"{best_metrics.get('Best_lamb', 0)}\n")
    print(f"Completed processing for {file}") 